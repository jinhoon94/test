package com.example.usersec.user;

import java.util.List;
import java.util.Optional;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
	int insert(User user); 
	List<User> findAll();
	Optional<User> findById(int id);
	int update(User user);
	int delete(int id);
}
