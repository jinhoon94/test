package com.example.usersec.user;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class UserDTO {
	String username;
	String password;
	String email;
}
