package com.example.usersec.user;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {

	@Autowired
	UserMapper userMapper; //xml은 resouces/mappper/UserMapper.xml

	public int insert(User user) {
		return userMapper.insert(user);
	}

	public List<User> findAll() {
		return userMapper.findAll();
	}

	public Optional<User> findById(int id) {
		return userMapper.findById(id);
	}

	public int update(User user) {
		return userMapper.update(user);
	}

	public int deleteById(int id) {
		return userMapper.delete(id);
	}
}
