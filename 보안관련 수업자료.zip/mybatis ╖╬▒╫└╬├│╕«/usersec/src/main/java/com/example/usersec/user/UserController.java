package com.example.usersec.user;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserService userService;
	
	/*
	 폼으로부터 객체형태로 데이터 전달(폼과 동일한 객체 생성)
	 등록이 성공했을 경우/실패 했을 경우
	 메시지 형태(status, message, data:요청사항반환)  
	 */
	//curl -X POST http://localhost:8080/api/user -H "Content-Type:application/json" -d "{\"username\": \"admin\",\"password\": \"1234\",\"email\": \"admin@example.com\"}"
	@PostMapping("user")
	public ResponseEntity<Map<String,Object>> postUser
	(@RequestBody UserDTO entity) {
		Map<String,Object> response =new HashMap<>();
		int status=userService.register(entity);
		System.out.println(status);
		
		if(status>0) {
			response.put("status","success");
			response.put("message","회원등록성공");
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
		
		response.put("status","fail");
		response.put("message","회원등록실패");
		return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
		
	}
	
	//curl -X GET http://localhost:8080/api/users
	//데이터 반환
	@GetMapping("users")
	public ResponseEntity<Map<String, Object>> getUsers() {
		Map<String,Object> response =new HashMap<>();
		List<User> users = userService.getAllUsers(); 
		 
		if (users.isEmpty()) {
	       response.put("status", "fail");
	       response.put("message", "사용자정보 반환 실패");
	       return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	    }
	        
	    response.put("status", "success");
	    response.put("message", "사용자 정보 반환 성공");
	    response.put("users", users);
	       
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	//curl -X GET http://localhost:8080/api/user/1	
	@GetMapping("user/{id}")
	public ResponseEntity<Map<String, Object>> getUser(@PathVariable int id) {
		Map<String,Object> response =new HashMap<>();
		Optional<User> user = userService.getUser(id); 
		//optinal로 반환해야 객체 확인이 쉬워짐 
		if (user.isEmpty()) {
	       response.put("status", "error");
	       response.put("message", "사용자정보 반환 실패!");
	       return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	    }
	        
	    response.put("status", "success");
	    response.put("message", "사용자 정보 반환 성공");
	    response.put("user", user.get());
	       
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	//curl -X PUT http://localhost:8080/api/user/1 -H "Content-Type:application/json" -d "{\"password\": \"5678\"}"
	@PutMapping("user/{id}")
	public ResponseEntity<Map<String, Object>> putUser(@PathVariable int id, @RequestBody UserDTO entity) {
		Map<String,Object> response =new HashMap<>();
		Optional<User> user = userService.updateUser(id,entity);
		if (user.isEmpty()) {
		       response.put("status", "fail");
		       response.put("message", "사용자정보 update 실패");
		       return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		        
		response.put("status", "success");
		response.put("message", "사용자 정보 update 성공");
		response.put("user", user.get());
		return new ResponseEntity<>(response, HttpStatus.OK);		
	}
	//curl -X DELETE http://localhost:8080/api/user/
	@DeleteMapping("user/{id}")
	public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable int id) {
		Map<String,Object> response =new HashMap<>();
		int status=userService.deleteById(id);
		if(status>0) {
			response.put("status","success");
			response.put("message","회원삭제성공");
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
		
		response.put("status","fail");
		response.put("message","회원삭제실패");
		return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
		
	}
	
}
