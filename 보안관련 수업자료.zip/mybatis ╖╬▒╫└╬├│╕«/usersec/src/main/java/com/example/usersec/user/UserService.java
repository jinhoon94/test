package com.example.usersec.user;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

@Service
public class UserService {

	@Autowired
	UserRepository userDao;

	public int register(UserDTO entity) {
		//BeanUtils.copyProperties(entity, entity);
		User user=User.builder()
				.username(entity.getUsername())
				.password(entity.getPassword())
				.email(entity.getEmail())
				.build();
		return userDao.insert(user);
	}

	public List<User> getAllUsers() {
		return userDao.findAll();
	}

	public Optional<User> getUser(int id) {
		return userDao.findById(id);
	}

	/*
	 id를 이용하여 사용자 정보 가져오기
	 
	 */
	public Optional<User> updateUser(int id, UserDTO entity) {
	    // 새로운 user 객체 생성
	    User user = User.builder().build();
	    
	    // DTO에서 user 객체로 값 복사
	    BeanUtils.copyProperties(entity, user);
	    
	    // ID로 사용자 조회
	    Optional<User> opuser = userDao.findById(id);
	    
	    if (opuser.isEmpty()) {
	        System.out.println("찾는 아이디 없음");
	        return opuser;  // id가 존재하지 않으면 비어있는 Optional 반환
	    }
	    
	    // DB에서 가져온 기존 user 객체
	    User dbuser = opuser.get();
	    
	    // DTO의 값이 null일 경우 DB에서 가져온 값으로 설정
	    if (user.getId() == 0) {
	        user.setId(dbuser.getId());
	    }
	    if (user.getUsername() == null) {
	        user.setUsername(dbuser.getUsername());
	    }
	    if (user.getPassword() == null) {
	        user.setPassword(dbuser.getPassword());
	    }
	    if (user.getEmail() == null) {
	        user.setEmail(dbuser.getEmail());
	    }
	    
	    System.out.println("*****" + user);
	    
	    // 업데이트 쿼리 실행
	    int status = userDao.update(user);
	    
	    // 업데이트 성공 여부 확인
	    if (status == 0) {
	        return Optional.empty();  // 업데이트 실패 시 빈 Optional 반환
	    }	
	    
	    return Optional.of(user);  // 업데이트 성공 시 user 객체 반환
	}


	public int deleteById(int id) {
		return userDao.deleteById(id);
	}
}
