package com.example.usersec.fileup;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "http://192.168.21.1:5555")
@RestController
@RequestMapping("/api")
public class FileupRestController{

    // 파일 업로드 처리
    @PostMapping("/upload")
    public ResponseEntity<Map<String, Object>> handleFileUpload(MultipartFile file) {

        Map<String, Object> response = new HashMap<>();

        // 파일이 없으면 에러 반환
        if (file.isEmpty()) {
            response.put("status", "error");
            response.put("message", "업로드된 파일이 없습니다.");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

        // 확장자 확인 (이미지 파일만 허용)
        String fileName = file.getOriginalFilename();
        if (fileName == null || !isImageFile(fileName)) {
            response.put("status", "error");
            response.put("message", "이미지 파일만 업로드 가능합니다.");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

        try {
            String dir = "C:\\Users\\admin\\Documents\\workspace-spring-tool-suite-4-4.28.1.RELEASE\\usersec\\uploads";  // 절대 경로 사용

            File directory = new File(dir);

            if (!directory.exists()) {
                directory.mkdir();
            }
            //문제코드
          
            File destFile = new File(directory + File.separator + file.getOriginalFilename());
            // 파일 저장
            file.transferTo(destFile);
            
            //수정코드
            /*
            // 1. 원래 파일명에서 안전한 이름 추출
            String originalFilename = file.getOriginalFilename();
            String safeFilename = FilenameUtils.getName(originalFilename);

            // 2. 저장 경로 구성
            File destFile = new File(directory + File.separator + safeFilename);

            // 3. 파일 저장
            file.transferTo(destFile);
			*/

            // 성공 메시지
            response.put("status", "success");
            response.put("message", "파일 업로드 및 저장 성공");
            response.put("filename", file.getOriginalFilename());

            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (IOException e) {
            response.put("status", "error");
            response.put("message", "파일 업로드 또는 처리 중 오류 발생: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 이미지 파일 확장자 확인 함수
    private boolean isImageFile(String fileName) {
        // 이미지 확장자 목록 (소문자, 대소문자 구분 없음)
        String[] imageExtensions = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp"};

        // 파일 이름의 확장자 가져오기
        String fileExtension = fileName.substring(fileName.lastIndexOf(".")).toLowerCase();

        // 이미지 확장자 목록에 포함되는지 확인
        for (String ext : imageExtensions) {
            if (fileExtension.equals(ext)) {
                return true;
            }
        }
        return false;
    }
}
